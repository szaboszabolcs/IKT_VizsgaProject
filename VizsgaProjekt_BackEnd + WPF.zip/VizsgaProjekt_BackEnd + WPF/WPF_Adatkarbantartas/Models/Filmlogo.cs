﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WPF_Adatkarbantartas.Models
{
    public partial class Filmlogo
    {
        public int Id { get; set; }
        public int FilmId { get; set; }
        public byte[] Logo { get; set; }

        public virtual Filmek Film { get; set; }
    }
}
